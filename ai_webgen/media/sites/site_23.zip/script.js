
        // Add any JavaScript functionality here if needed
        console.log("Welcome to the Blockchain-Based Voting System!");
    