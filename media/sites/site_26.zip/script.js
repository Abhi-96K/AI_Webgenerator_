
    function joinGame(gameName) {
        alert("You have joined the game: " + gameName);
    }
